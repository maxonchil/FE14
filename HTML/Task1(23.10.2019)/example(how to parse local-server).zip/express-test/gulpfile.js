const gulp = require( 'gulp' );
const sass = require( 'gulp-sass' );
const autoprefixer = require( 'gulp-autoprefixer' );
const clean = require( 'gulp-clean' );


gulp.task( 'clean', () => gulp.src( 'public/*', { read: false } )
	.pipe( clean( ) )
);

gulp.task( 'css', () => 
	gulp.src( './src/css/styles.scss' )
    .pipe( sass() )
    .pipe( autoprefixer( {
			cascade: false
		} ) )
    .pipe( gulp.dest('./public/') )
);

gulp.task( 'css:watch', () => 
  gulp.watch( './src/**/*.scss', gulp.series( 'css' ) )
);

gulp.task( 'default', gulp.series( 'clean', 'css', 'css:watch' ) );
